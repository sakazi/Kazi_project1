
/**
 * IVoteService interface : identities accessed method for possible implementation
 * in Vote Service classes
 * Here we can sublit an answer or display results for a given question
 */
public interface IVoteService {

    public void submitAnswer(Student student, Choice answers);

    public void results();
}
