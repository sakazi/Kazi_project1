/**
 * Choice : abstract class used by differents possible choices for a questions
 */
public abstract class Choice {
    public abstract Object getChoice();
}
