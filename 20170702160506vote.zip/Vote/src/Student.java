/**
 * Student class
 * each student is identified by a unique studentID
 */
import java.util.Objects;

public class Student {

    private String studentID;

    public Student(String studentID) {
        this.studentID = studentID;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.studentID);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        return obj.toString().equals(studentID);
    }

    @Override
    public String toString() {
        return studentID;
    }

}
