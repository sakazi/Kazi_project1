
import java.util.Iterator;
import java.util.Map;

public class VoteService extends AbstractVoteService implements IVoteService {

    public VoteService(Question question) {
        super(question);
    }

    /**
     * adding answer choice to the sibmission list
     *
     * @param student
     * @param choice
     */
    @Override
    public void submitAnswer(Student student, Choice choice) {
        submissions.add(new Submission(student, question, choice));
    }

    /**
     * Output results
     */
    @Override
    public void results() {
        Iterator<Submission> submissionIterator = submissions.iterator();
        if (question.getQuestionType().equals(QuestionType.SINGLECHOICE)) {
            while (submissionIterator.hasNext()) {
                Submission submission = submissionIterator.next();
                Choice answer = submission.getAnswer();
                if (!results.containsKey((Answer) answer.getChoice())) {
                    results.put((Answer) answer.getChoice(), 1);
                } else {
                    results.put((Answer) answer.getChoice(), results.get((Answer) answer.getChoice()) + 1);
                }
            }

        } else {
            while (submissionIterator.hasNext()) {
                Submission submission = submissionIterator.next();
                Choice answer = submission.getAnswer();
                Answer[] answers = (Answer[]) answer.getChoice();
                for (Answer answer1 : answers) {
                    if (!results.containsKey(answer1)) {
                        results.put(answer1, 1);
                    } else {
                        results.put(answer1, results.get(answer1) + 1);
                    }
                }
            }
        }
        System.out.println("Results for question \"" + question + "\"  : ( " + question.getQuestionType().getType() + " question )");
        for (Map.Entry<Answer, Integer> entry : results.entrySet()) {
            Answer key = entry.getKey();
            Integer value = entry.getValue();
            System.out.println(key.getAnswer() + " : " + value);

        }
    }

}
