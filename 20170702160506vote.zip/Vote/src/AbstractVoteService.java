/**
 * AbstractVoteService an abstract class to hold attributes for VoteService
 */
import java.util.HashMap;
import java.util.HashSet;
import java.util.Set;

public abstract class AbstractVoteService {

    protected Question question;
    protected Set<Submission> submissions;
    protected HashMap<Answer, Integer> results;

    public AbstractVoteService(Question question) {
        this.question = question;
        this.submissions = new HashSet<>();
        this.results = new HashMap<>();
    }

}
