/**
 * class SingleChoice: a question that have a single choice as an answer 
 */
import java.util.List;
import java.util.Random;


public class SingleChoice extends Choice {

    Question question;
    Answer choice;

    public SingleChoice(Question question) {
        Random rand = new Random();
        this.question = question;
        List<Answer> answers = this.question.getAnswers();
        int choice = rand.nextInt(answers.size());
        this.choice= answers.get(choice);
    }

    @Override
    public Object getChoice() {
        return choice;
    }
}
