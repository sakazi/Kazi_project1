
/**
 * This class simulate the whole process of creating generating students
 * questions, configure answers, submit all students answers
 * and call the iVote Service output function to display the result.
 */
import java.util.Arrays;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

public class SimulationDriver {

    /**
     * Main method
     *
     * @param args
     */
    public static void main(String[] args) {
        int numberOfStudents = 100;
        Student[] students = generateListStudents(numberOfStudents);
        Question[] questions = {
            new Question("aaaa ?", Arrays.asList("A.", "B.", "C.", "D"), QuestionType.MULTIPLECHOICE),
            new Question("bbbb ?", Arrays.asList("1. Right", "2. Wrong"), QuestionType.SINGLECHOICE),
            new Question("cccc ?", Arrays.asList("A.", "B.", "C.", "D"), QuestionType.MULTIPLECHOICE),
            new Question("dddd ?", Arrays.asList("1. Right", "2. Wrong"), QuestionType.SINGLECHOICE)
        };
        for (Question question : questions) {
            IVoteService voteService = new VoteService(question);
            for (int i = 0; i < students.length; i++) {
                voteService.submitAnswer(students[i], randomlySelectAnswer(question));
            }
            voteService.results();
        }

    }

    /**
     *
     * @param numberStudents
     * @return array of students
     */
    private static Student[] generateListStudents(int numberStudents) {
        Set<Student> students = new HashSet<>();
        Random rand = new Random();
        while (students.size() < numberStudents) {
            int identifier = 1000 + rand.nextInt(10000);
            Student student = new Student(identifier + "");
            students.add(student);
        }
        return students.toArray(new Student[numberStudents]);
    }

    /**
     *
     * @param question1
     * @return a choice object for a question depending on question type
     */
    private static Choice randomlySelectAnswer(Question question1) {
        Choice choice;
        if (question1.getQuestionType().equals(QuestionType.SINGLECHOICE)) {
            choice = new SingleChoice(question1);
        } else {
            choice = new MultipleChoice(question1);
        }
        return choice;
    }
}
