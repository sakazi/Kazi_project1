/**
 * class MultipleChoice: a question that have one or more than one choice as an answer 
 */
import java.util.List;
import java.util.Random;

public class MultipleChoice extends Choice {

    Question question;
    Answer[] choices;

    public MultipleChoice(Question question) {
        Random rand = new Random();
        this.question = question;
        List<Answer> answers = this.question.getAnswers();
        int numberOfChoices = rand.nextInt(answers.size());
        this.choices = new Answer[numberOfChoices];
        int i = 0;
        while (i < numberOfChoices) {
            int selected = rand.nextInt(this.question.getAnswers().size());
            if (!contains(answers.get(selected))) {
                this.choices[i] = answers.get(selected);
                i++;
            }
        }
    }

    public Object[] getChoice() {
        return choices;
    }

    private boolean contains(Answer answer) {
        for (Answer choice : choices) {
            if (choice != null && choice.equals(answer)) {
                return true;
            }
        }
        return false;
    }

}
