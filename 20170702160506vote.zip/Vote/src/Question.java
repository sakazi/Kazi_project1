/**
 * Question class represents a question by a string, 
 * a list of answer and specifies question type 
 */
import java.util.ArrayList;
import java.util.List;

public class Question {

    private String question;
    private List<Answer> answers;
    private QuestionType questionType;

    public Question(String question, List<String> answers, QuestionType questionType) {
        this.question = question;
        this.answers = new ArrayList<>();
        for (String answer : answers) {
            this.answers.add(new Answer(answer));
        }
        this.questionType = questionType;

    }

    public String getQuestion() {
        return question;
    }

    public void setQuestion(String question) {
        this.question = question;
    }

    public List<Answer> getAnswers() {
        return answers;
    }

    public void setAnswers(List<Answer> answers) {
        this.answers = answers;
    }

    public QuestionType getQuestionType() {
        return questionType;
    }

    @Override
    public String toString() {
        return question;
    }

}
