/**
 * QuestionType enum type: represents two possible questions type : Single Choice and Multiple Choice
 */
public enum QuestionType {
    SINGLECHOICE("Single Choice"), MULTIPLECHOICE("Multiple Choice");

    private final String type;

    private QuestionType(String value) {
        this.type = value;
    }

    public String getType() {
        return type;
    }
    
    
}
