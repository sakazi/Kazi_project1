
/**
 * class Submission represents submission for a student to a question
 * by an answer choice
 */
import java.util.Objects;

public class Submission {

    private Student student;
    private Question question;
    private Choice answer;

    public Submission(Student student, Question question, Choice answer) {
        this.student = student;
        this.question = question;
        this.answer = answer;
    }

    public Choice getAnswer() {
        return answer;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 97 * hash + Objects.hashCode(this.student);
        return hash;
    }

    /**
     * Equality of submission type is for the same student object
     *
     * @param obj
     * @return
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Submission other = (Submission) obj;
        if (!Objects.equals(this.student, other.student)) {
            return false;
        }
        return true;
    }

}
